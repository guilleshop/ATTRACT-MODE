uniform sampler2D texture;
uniform vec3 colour_top;
uniform vec3 colour_bottom;
uniform float repeats;

void main()
{
	// lookup the pixel in the texture
	vec4 pixel = texture2D(texture, gl_TexCoord[0].xy);
	
	// Mix the colours as a vertical gradient
	vec3 colour = mix(colour_bottom,colour_top,fract(gl_TexCoord[0].y * repeats));
	
	// Colour the surface
    gl_FragColor = pixel * vec4(colour,1.0);
}
