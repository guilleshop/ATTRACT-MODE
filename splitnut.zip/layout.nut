// ----------------------------------------------------------------------------
//
// "Splitnut" theme for Attract-Mode Front-End
// Version 1.82   (2026)
// Coded by gnolivos from the AM Discord channel
//
// I take no credit for the many portions of code forked from
// various themes and custom code and assets / ideas found across the web.
// Credit to all the amazing layout coders out there.
//
// ----------------------------------------------------------------------------
//
// This theme is free for private use only
//
// -----------------------------------------------------------------------------------------------------------
// ***IMPORTANT:***
//
// This theme requires Attract Mode PLUS. Regular AM won't work well or at all.
// Download it here: https://github.com/oomek/attractplus
//
// Make sure you download all needed modules and place them in your [AM+ install]/modules/ folder:
// Animate, Inertia, Wheel, Animated-Joystick, and Mask.
// Some can be found at: https://github.com/oomek/attract-extra/tree/main/modules
// ...and others at: https://github.com/Chadnaut/Attract-Mode-Modules/tree/master/modules
//
// If you want cabinet artwork, put it all inside a "cabinet" folder and attach to AM+:
// Configure > Emulator > Edit Emulator > Add Artwork >
// Name it 'cabinet' > point to the folder with the cabinet art inside it.
// Then go into Splitnut layout parameters and point to it:
// Configure > Displays > [your Splitnut display] > Layout Options > Source of Cabinet Image > [select 'cabinet']
// A good source for cabinet artwork files here: https://emumovies.com/files/file/548-mame-cabinets-pack/
//
// Lastly, make sure to check the Layout configuration screens, there are TONS of options to tweak:
// Configure > Displays > [your Splitnut display] > Layout Options >
//
// -----------------------------------------------------------------------------------------------------------
// Huge thanks to Oomek and Chadnaut for putting up with all my questions!
// -----------------------------------------------------------------------------------------------------------

class UserConfig {
    </ label=" ", help=" ", options=" ", order=1 /> divider1 = "";
    </ label="-----GAME PREVIEW-----", help="Manage settings related to the game preview snap/video.", options=" ", order=3 /> divider2 = "";
    //-----------------------------------------------------------------
    </ label="Preview Type", help="Video = video snap     Screenshot = game screenshot.", options="video,screenshot,off", order=4 /> Preview_Type = "video";
    </ label="Preview Size (%)", help="Adjust the size of the video/snap preview.", options="110,105,100,95,90", order=5 /> snap_scale = "105";
    </ label="Preview Video Sound Muted?", help="Yes = sound muted/disabled     No = sound enabled.", options="yes,no", order=12 /> mute_videoSnaps = "no";

    </ label=" ", help=" ", options=" ", order=13 /> divider3 = "";
    </ label="-----WHEEL-----", help="Manage settings related to the wheel.", options=" ", order=14 /> divider4 = "";
    //-----------------------------------------------------------------
    </ label="Wheel Artwork Source", help="Choose between marquee or wheel artwork for the wheel.", options="marquee,wheel,logos", order=16 /> spinwheel_art = "wheel";
    </ label="Wheel Game Count", help="The number of games on the wheel.", options="21,19,17,15,13,11,9,7,5,3", order=17 /> art_count = "11";
    </ label="Wheel Transition Time (ms)", help="Time in milliseconds for wheel spin. Lower is faster. Sync = matches all other animations.", options="1000,400,300,200,160,150,140,130,120,110,100,90,80,70,60,50,40,30,20,10,sync", order=18 /> transition_ms = "sync";
    </ label="Wheel Vertical Height (%)", help="The height of the wheel relative to screen height.", options="120,110,100,95,90", order=19 /> wheel_percent_height = "110";
    </ label="Wheel Selected Game Size (%)", help="The size of the selected game on the wheel.", order=21, options="300,270,250,220,200,180,140,120,100" /> wheel_selected_size = "270";
	</ label="Wheel Brightness (%)", help="The brightness for unselected wheel games.  0% = dark.", options="100,90,80,70,60,50,40,30,20,10,0", order=22 /> wheel_small_brightness="100";
	</ label="Wheel Transparency (%)", help="The transparency for unselected wheel games.  0% = invisible", options="100,90,80,70,60,50,40,30,20,10,0", order=23 /> wheel_small_alpha = "70";
    </ label="Wheel Idle Fade (%)", help="The amount of fade to the wheel after idle.  0% = invisible", options="100,90,80,70,60,50,40,30,20,10,5,0", order=24 /> wheel_fade_alpha = "20";
    </ label="Wheel Fade Speed (seconds)", help="The speed at which the wheel fades in seconds.", options="1.4,1.2,1.0,0.8,0.6,0.5,0.4,0.3,0.2,0.1", order=25 /> wheel_fade_speed = "0.4";
    </ label="Wheel Size Gradual?", help="Yes = wheel entries are gradually scaled up     No = fixed size.", options="yes,no", order=26 /> wheel_smooth_resize = "yes";
    </ label="Spin Wheel After Idle (minutes)", help="The amount of time in minutes until random spin begins.", options="60,30,15,10,5,off", order=28 /> idle_time = 5;
    </ label="Mark Favorite Games on Wheel", help="Show favorites tag icons on the wheel.  'Auto' will disable icons in favorites layout", options="auto,on,off", order=29 /> fav_icon = "auto";

    </ label=" ", help=" ", options=" ", order=30 /> divider5 = "";
    </ label="-----BACKGROUND-----", help="Manage settings related to the background artwork.", options=" ", order=31 /> divider6 = "";
    //-----------------------------------------------------------------
    </ label="Background Art", help="Display the flyer/fanart/screenshot/video etc. in background.", options="flyer,fanart,snap,video,backgrounds,none", order=32 /> enable_bg_art = "backgrounds";
    </ label="Background Brightness (%)", help="Intensity of background brightness.", options="100,90,80,70,60,50,40,30,20,10,0", order=33 /> bg_dimming = "30";
    </ label="Background Vignetting (%)", help="Intensity of background vignetting.", options="100,90,80,70,60,50,40,30,20,10,0", order=34 /> bg_vignette_strength = "80";
    </ label="Background Action While Scrolling", help="Change = background changes while scrolling     Static =  background static     Remove = background is removed.", options="change, static, remove", order=36 /> background_changes = "change";

    </ label=" ", help=" ", options=" ", order=50 /> divider7 = "";
    </ label="-----SPECIAL-----", help="Manage other special settings.", options=" ", order=51 /> divider8 = "";
    //-----------------------------------------------------------------
	</ label="Animation Speed", help="Adjust the speed of the video/snap frame motion and other effects.", options="snappy,normal,relaxed", order=53 /> effect_speed = "normal";
	</ label="Extra Information (top left)", help="Choose additional information to display.", options="off, emulator, display-name, rom-name, play-time, play-time digital", order=55 /> extra_info = "play-time digital";
    </ label="Game Counter (bottom right)", help="Display the number of games available for the current display.  'Expanded' will include the display name.", options="off, simple, expanded", order=60 /> game_counter = "expanded";
    </ label="Show Info Icons", help="Display icons for number of players and input type for each game.", options="on, off", order=60 /> show_info_icons = "on";
    </ label="Special Joystick Help/Animations", help="Show joystick help/animations.", options="on,off", order=70 /> special_anims = "on";
    </ label="Key Assignment for Favorites", help="Assign your key to handle favorites. Short press will jump to favorites, long press will add/remove favorite.", options="custom6,custom5,custom4,custom3,custom2,custom1,none", order=75 /> fav_key = "none";

    </ label=" ", help=" ", options=" ", order=80 /> divider9 = "";
    </ label="-----GAME TRANSITION-----", help="Manage settings related to the transition effect when launching a game.", options=" ", order=81 /> divider10 = "";
    //-----------------------------------------------------------------
    </ label="Transition Effect to/from Game", help="The effect style for the transition when launching a game, as well as returning back from game.", options="fade,round-iris,square-iris,off", order=85 /> fadeType = "round-iris";
    </ label="Transition Effect Level", help="Low = basic transition effect     Medium = adds fade out     High = adds dialog zoom out.", options="high,medium,low", order=90 /> enhancedFadeEffects = "high";
    </ label="Transition To Game Time (ms)", help="The amount of time in milliseconds to run the transition effect to game.", options="3000,2500,2000,1500,1000,900,800,700,600,500,400,300,200,100", order=95 /> toGameRunTime = "800";
    </ label="Transition From Game Time (ms)", help="The amount of time in milliseconds to run the transition effect back from game.", options="3000,2500,2000,1500,1000,900,800,700,600,500,400,300,200,100", order=100 /> fromGameRunTime = "400";

    </ label=" ", help=" ", options=" ", order=110 /> divider11 = "";
    </ label="-----SCANLINES-----", help="Manage settings related to scanline effects.", options=" ", order=111 /> divider12 = "";
    //-----------------------------------------------------------------
    </ label="Scanlines", help="Show scanline effect.", options="dark,medium,light,off", order=120 /> enable_scanlines = "medium";
    </ label="Scanline Type", help="Select the type of scanline to apply to the entire layout.", options="tight,normal,loose,CRT,aperture", order=125 /> scanline_type = "normal";
    </ label="Scanline order", help="Select whether to apply scanlines to entire screen, or only apply to background.", options="entire screen, background", order=130 /> scanline_order = "background";

    </ label=" ", help=" ", options=" ", order=140 /> divider13 = "";
    </ label="-----EXIT-----", help="Manage settings related to the front-end application exit action.", options=" ", order=141 /> divider14 = "";
    //-----------------------------------------------------------------
    </ label="Exit Action", help="The action to take when exiting. (Windows only)", options="hibernate,shutdown,desktop", order=150 /> exit_action = "desktop";

    </ label=" ", help=" ", options=" ", order=999 /> divider999 = "";
    //-----------------------------------------------------------------
}

local my_config = fe.get_config();

fe.load_module("animate");
fe.load_module("inertia");
fe.load_module("wheel");
fe.load_module("animated-joystick");
fe.load_module("mask");

// Set these up if you want special functionality/exclusons etc. based on these display names.
SettingsDisplayName <- "Settings";
FavoritesDisplayName <- "Favorite Games";

flx <- fe.layout.width;
fly <- fe.layout.height;
flw <- fe.layout.width;
flh <- fe.layout.height;
baseY <- 0; //base Y coordinate origin.

effect_speed <- my_config["effect_speed"]; //we will use this speed in ms to define ms timing for most animations moving forward.
effect_faster <- 140; //ms
effect_normal <- 340; //ms
effect_slower <- 570; //ms

switch (effect_speed) {
    case "snappy":
        effect_speed = effect_faster;
        break;
    case "normal":
        effect_speed = effect_normal;
        break;
    case "relaxed":
        effect_speed = effect_slower;
        break;
    default:
        effect_speed = effect_normal;
        break;
}

// Ambient sound in display menu (the 'Genres' menu)
if (fe.list.display_index < 0) {   //this is the displays menu
	if ( FeVersionNum < 310 ) {
		local mysong = fe.add_sound("assets/sounds/arcade83.mp3");
		mysong.loop = false;
		mysong.playing = true;
	}
	else
	{
		fe.ambient_sound.file_name = "assets/sounds/arcade83.mp3";
		fe.ambient_sound.loop = true;
		fe.ambient_sound.playing = true;
	}

}
	else
{
	fe.ambient_sound.playing = false;
}

// Mute audio variable - definable via user config ------------------------ START

if (my_config["mute_videoSnaps"] == "yes") {
    ::videoSound <- Vid.NoAudio;
}
if (my_config["mute_videoSnaps"] == "no") {
    ::videoSound <- Vid.Default;
}

// mute audio variable - definable via user config ------------------------ END

// Default background image (if no art present) ------------- START

bg <- fe.add_image("assets/general/background.png", 0, 0 + baseY, flw, flh);

// Default background image ------------- END



// BACKGROUND ART --------------------------------------------------------- START
local whichBG = null;
local vidFlag = null;
switch (my_config["enable_bg_art"]) {
    case "flyer":
        whichBG = "flyer";
        break;
    case "fanart":
        whichBG = "fanart";
        break;
    case "snap":
        whichBG = "snap";
        vidFlag = Vid.ImagesOnly;
        break;
    case "backgrounds":
        whichBG = "backgrounds";
        break;
    case "video":
        whichBG = "snap";
        vidFlag = Vid.NoAudio;
        break;
}

// Now apply background
local bgart = fe.add_artwork(whichBG, -300, 0, fe.layout.width * 1.2, 0);
bgart.preserve_aspect_ratio = true;
local bgdim = my_config["bg_dimming"].tofloat() * 255 * 0.01;
bgart.set_rgb(bgdim, bgdim, bgdim);
local vignette_strength = my_config["bg_vignette_strength"].tofloat() * 255 * 0.01;
local mask = fe.add_image("assets/general/mask_edges.png", 0, 0, fe.layout.width, fe.layout.height);
mask.preserve_aspect_ratio = false;
mask.alpha = vignette_strength;

if (whichBG == "snap") {
    bgart.video_flags = vidFlag;
}
if (my_config["background_changes"] == "change") bgart.trigger = Transition.ToNewSelection;
else bgart.trigger = Transition.EndNavigation;

// Always slide in from the left, moving right to final position
local bgart_cfg = { when = Transition.EndNavigation, property = "x", start = bgart.x - flw * 0.15, end = bgart.x, time = effect_speed * 1.5, tween = Tween.Cubic };
animation.add(PropertyAnimation(bgart, bgart_cfg));

if (my_config["background_changes"] == "remove") {
    fe.add_transition_callback("hide_bg");
    function hide_bg(ttype, var, ttime) {
        if (ttype == Transition.StartLayout || ttype == Transition.ToNewList || ttype == Transition.EndNavigation) {
            bgart.visible = true;
        }
        if (ttype == Transition.ToNewSelection) {
            bgart.visible = false;
        }
        return false;
    }
}
// Background art --------------------------------------------------------- END


//----------------------------------------------------------------------------
//  VIDEO SNAP WITH FRAME(video or screenshot) --------------------------START
//  Here comes the more interesting code to add the snap preview and the frame.
//  This code adapts the frame to the proper aspect ratio of the snap video.
//----------------------------------------------------------------------------

local snapscale = my_config["snap_scale"].tofloat() * 1.5;
local snapwidth = fly * snapscale * 0.01;
local snapheight = snapwidth;
local padding = 0; //this value may have to be changed if you use a different/custom frame border width in your custom frame image.
local mask = fe.add_image("assets/general/maskright.png");

mask.visible = false;

//Video portion added to a surface
local VideoPreviewSurf = fe.add_surface(snapwidth + padding * 2, snapheight + padding * 2);
local SurfWidthStatic = VideoPreviewSurf.width;
VideoPreviewSurf.origin_x = VideoPreviewSurf.width / 2;
VideoPreviewSurf.origin_y = VideoPreviewSurf.height / 2;
VideoPreviewSurf.set_pos(flw * 0.8, fly * 0.45 + baseY);
VideoPreviewSurf.zorder = 400;

local VideoObj = Mask(VideoPreviewSurf.add_artwork("bogus", 0 + padding, 0 + padding, snapwidth, snapheight));

if (my_config["Preview_Type"] != "off") {
    VideoObj = Mask(VideoPreviewSurf.add_artwork("snap", 0 + padding, 0 + padding, snapwidth, snapheight));
    VideoObj.mask = mask;
}

VideoObj.preserve_aspect_ratio = true;
VideoObj.trigger = Transition.EndNavigation;
VideoObj.video_flags = videoSound;

if (my_config["Preview_Type"] == "screenshot") {
    VideoObj.video_flags = Vid.ImagesOnly;
}

if (my_config["background_changes"] == "change") VideoPreviewSurf.trigger = Transition.ToNewSelection;
else VideoPreviewSurf.trigger = Transition.EndNavigation;

local VideoPreviewSurf_cfg = { when = Transition.EndNavigation, property = "x", start = flw * 0.15 + flw * 0.8, end = VideoPreviewSurf.x, time = effect_speed * 1.5, tween = Tween.Cubic };
animation.add(PropertyAnimation(VideoPreviewSurf, VideoPreviewSurf_cfg));


local VideoPreviewSurf_cfg = { when = Transition.EndNavigation, property = "alpha", start = 0, end = 255, time = effect_speed * 4, tween = Tween.Cubic };
animation.add(PropertyAnimation(VideoPreviewSurf, VideoPreviewSurf_cfg));

if (my_config["background_changes"] == "remove") {
    fe.add_transition_callback("hide_bg");
    function hide_bg(ttype, var, ttime) {
        if (ttype == Transition.StartLayout || ttype == Transition.ToNewList || ttype == Transition.EndNavigation) {
            VideoPreviewSurf.visible = true;
        }
        if (ttype == Transition.ToNewSelection) {
            VideoPreviewSurf.visible = false;
        }
        return false;
    }
}

// VIDEO SNAP WITH FRAME(video or screenshot) -----------------END

// EXTRA INFO to display  (top left)------------------------------------------------ START

function PlayedTime()  //my custom function to format nicely without decimals etc.
{
    local PlayedSeconds = fe.game_info( Info.PlayedTime ).tointeger();

	if (PlayedSeconds == 0) {
        return "0 minutes";
    }
	else if (PlayedSeconds < 60) {
        return "1 minute";
    }
    else if (PlayedSeconds < 3600) {
        local minutes = PlayedSeconds / 60;
        return minutes + " minutes";
    }
    else if (PlayedSeconds < 86400) {
        local hours = PlayedSeconds / 3600;
        return hours + " hours";
    }
    else {
        local days = PlayedSeconds / 86400;
        return days + " days";
    }
}

local displayextra = null;
local extrainfoFont_size = fly * 0.037; //default font size
local extra_info_offset = fly * 0.003;
switch (my_config["extra_info"]) {
    case "rom-name":
        displayextra = "[Name]";
        break;

    case "display-name":
        local filterindex = fe.list.filter_index;
        local filtername = "";
        if (filterindex != 0) {
            filtername = " - [FilterName]";
        }
        displayextra = "[DisplayName]" + filtername;
        extrainfoFont_size = fly * 0.05; //slightly larger if displaying the Display Name.
        break;

    case "emulator":
        displayextra = "[Emulator]";
        break;

    case "play-time":
        displayextra = "PLAYED: " + "[PlayedCount]" + "  ([!PlayedTime])";
        break;

    case "play-time digital":
        displayextra = "PLAYED: " + "[PlayedCount]" + "  ([!PlayedTime])";
        break;

    case "off":
        displayextra = " ";
        break;
}

local extra_infoText = fe.add_text(displayextra, flx * 0.013, flx * 0.003 + baseY, flx * 0.521, extrainfoFont_size);
extra_infoText.set_rgb(150, 150, 150);
extra_infoText.font = "SF Slapstick Comic Bold Oblique.ttf"; //this free font is for personal use and can be downloaded here: https://www.dafont.com/sf-slapstick-comic.font
extra_infoText.align = Align.Left;
extra_infoText.zorder = 7300; //always on top
extra_infoText.outline = extra_info_offset;
if (my_config["extra_info"] == "play-time digital") {
    extra_infoText.set_rgb(139, 105, 18);
    extra_infoText.font = "SFDigitalReadout-MediumObli.ttf";
    //extra_infoText.zorder= 8887;
}

// Extra info to display  --------------------------------------------------------- END

// GAME COUNTER  (bottom right) ------------------------------------------------ START

local displaycounter = null;
local currDispFilt = "";
local filterindex = fe.list.filter_index;
local filtername = "";

if (filterindex != 0) {
    filtername = " - [FilterName]";
}
currDispFilt = "[DisplayName]" + filtername;
switch (my_config["game_counter"]) {
    case "simple":
        displaycounter = "([ListEntry]/[ListSize]) ";
        break;
    case "expanded":
        if (my_config["extra_info"] == "display-name") displaycounter = "([ListEntry]/[ListSize]) ";
        else displaycounter = currDispFilt + " ([ListEntry]/[ListSize]) ";
        break;
    case "off":
        displaycounter = " ";
        break;
}

//local debugTXT = fe.add_text( "***" + filtername + "***" , 960, 20 +baseY, fly*0.48, fly*0.04 );
//debugTXT.zorder=99999;

local counterFont_size = fly * 0.037;

local counter_infoText = fe.add_text(displaycounter, 0, fly - 1.4 * counterFont_size + baseY, flx, counterFont_size); //use 82 instead of 145 to move up if desired.
counter_infoText.set_rgb(150, 150, 150);
counter_infoText.align = Align.Right;
counter_infoText.font = "SF Slapstick Comic Bold Oblique.ttf"; //this free font is for personal use and can be downloaded here: https://www.dafont.com/sf-slapstick-comic.font
local counter_shadow_offset = fly * 0.003;
counter_infoText.zorder = 7300;
counter_infoText.outline = counter_shadow_offset;

// Game Counter  --------------------------------------------------------- END

// CABINET ARTWORK--------------------------------------------------START

local cabpicPosX = flx * 0.065;
local cabpicPosY = fly * 0.227;
local cabpic = fe.add_artwork("cabinet", cabpicPosX, cabpicPosY + baseY, 0, fly * 0.65);
cabpic.preserve_aspect_ratio = true;
cabpic.mipmap = true;
cabpic.trigger = Transition.EndNavigation;

local shadowOffset = 1;
local cabpicShadow = fe.add_artwork("cabinet", cabpicPosX + shadowOffset, cabpicPosY + shadowOffset, cabpic.width, cabpic.height);
cabpicShadow.mipmap = true;
cabpicShadow.preserve_aspect_ratio = true;
cabpicShadow.x = cabpic.x + shadowOffset;
cabpicShadow.y = cabpic.y + shadowOffset;
cabpicShadow.set_rgb(0, 0, 0);
cabpicShadow.alpha = 180;
cabpicShadow.trigger = Transition.EndNavigation;
cabpicShadow.zorder = 6799;
cabpic.zorder = 6800;

local cabpic_cfg = { when = Transition.EndNavigation, property = "x", start = 0 - cabpic.width - 370, end = cabpicPosX, time = effect_speed, tween = Tween.Cubic };
animation.add(PropertyAnimation(cabpic, cabpic_cfg));

local cabpicShadow_cfg = { when = Transition.EndNavigation, property = "x", start = 0 - cabpicShadow.width - 370 + shadowOffset, end = cabpicPosX + shadowOffset, time = effect_speed, tween = Tween.Cubic };
animation.add(PropertyAnimation(cabpicShadow, cabpicShadow_cfg));

// Cabinet artwork--------------------------------------------------END

// GAME INFO--------------------------------------------------START

local InfoFontsize = fly * 0.0296 * 1.4;
local txtShadowOffset = fly * 0.0038;

function formatManufYear() {
    //do this to avoid having a single comma when no info is available etc.
    local m = fe.game_info(Info.Manufacturer);
    local y = fe.game_info(Info.Year);
    if (m.len() > 0 && y.len() > 0) return y + ", " + m;
    if (m.len() == 0 && y.len() > 0) return y;
    return m;
}

// Gradient shaders

local colour_shader = fe.add_shader(Shader.Fragment, "assets/shaders/gradient.frag");
colour_shader.set_param("colour_top", 1.25, 1.25, 1.25); //beyond 1.0 seems to extend gradient midpoint upward
colour_shader.set_param("colour_bottom", 0.361, 0.788, 0.898);
colour_shader.set_param("repeats", 1);

// Create surfaces for title
local surfaceTitle = fe.add_surface(flx * 0.8, InfoFontsize + txtShadowOffset * 2 + 2);
surfaceTitle.set_pos(flx * 0.02, fly * 0.92 + baseY);
local TitleText = surfaceTitle.add_text("[Title]", txtShadowOffset, txtShadowOffset, surfaceTitle.width - txtShadowOffset, (surfaceTitle.height - txtShadowOffset) * 0.8);
TitleText.font = "ARLRDBD.ttf";
TitleText.align = Align.Left;
surfaceTitle.shader = colour_shader;
surfaceTitle.zorder = 7300;
TitleText.zorder = 7300;
TitleText.outline = txtShadowOffset;

// Create surfaces for manuf/year
local surfaceManuf = fe.add_surface(surfaceTitle.width, surfaceTitle.height * 0.74);
surfaceManuf.set_pos(surfaceTitle.x * 1.2, surfaceTitle.y - surfaceTitle.height * 0.58);
local ManufText = surfaceManuf.add_text("[!formatManufYear]", 0, 0, surfaceManuf.width, surfaceManuf.height * 0.8);
ManufText.font = "ARLRDBD.ttf";
ManufText.align = Align.Left;
surfaceManuf.shader = colour_shader;
surfaceManuf.zorder = 7300;
ManufText.zorder = 7300;
ManufText.outline = txtShadowOffset * 0.8;

//  Add input icons

function MainInput(index_offset) {
    local controlinfo = fe.game_info(Info.Control, index_offset).tolower();
    if (controlinfo.len() >= 1) {
        //order matters here!
        if (controlinfo.find("trackball") != null) return "trackball";
        if (controlinfo.find("analog") != null) return "analog";
        if (controlinfo.find("joystick") != null) return "joystick";
        if (controlinfo.find("trigger") != null) return "triggerstick";
        if (controlinfo.find("pedal") != null) return "wheel";
        if (controlinfo.find("paddle") != null) return "dial";
        if (controlinfo.find("dial") != null) return "dial";
        if (controlinfo.find("gun") != null) return "lightgun";
        if (controlinfo.find("button") != null) return "button";
    }
    return "button"; //if no match
}

local inputicon = null;
if (my_config["show_info_icons"] == "on") {
    inputicon = fe.add_image("assets/inputs/[!MainInput]", surfaceTitle.x * 1.09, surfaceManuf.y - 1.45 * surfaceManuf.height, fly * 0.06, 0);
    inputicon.preserve_aspect_ratio = true;
    inputicon.mipmap = true;
    inputicon.trigger = Transition.EndNavigation;
    inputicon.zorder = 7300;
}

// Add player icons

function numplayers(index_offset) {
    local playinfo = fe.game_info(Info.Players, index_offset).tolower();
    if (playinfo.len() >= 1) {
        //order matters here!
        if (playinfo.find("2p alt") != null) return "2palt";
        if (playinfo.find("3p alt") != null) return "3palt";
        if (playinfo.find("4p alt") != null) return "4palt";
        if (playinfo.find("5p alt") != null || playinfo.find("6p alt") != null || playinfo.find("7p alt") != null || playinfo.find("8p alt") != null) return "4paltplus";
        if (playinfo.find("2p sim") != null) return "2psim";
        if (playinfo.find("3p sim") != null) return "3psim";
        if (playinfo.find("4p sim") != null) return "4psim";
        if (playinfo.find("5p sim") != null || playinfo.find("6p sim") != null || playinfo.find("7p sim") != null || playinfo.find("8p sim") != null) return "4psimplus";
        return playinfo.slice(0, 1); // else return match for number just to show something close enough
    }
    return "1"; //if no match just show 1P
}

local playericon = null;
if (my_config["show_info_icons"] == "on") {
    playericon = fe.add_image("assets/players/[!numplayers]", inputicon.x + inputicon.width * 1.03, inputicon.y * 0.994, fly * 0.092, 0);
    playericon.preserve_aspect_ratio = true;
    playericon.mipmap = true;
    playericon.trigger = Transition.EndNavigation;
    playericon.zorder = 7300;
}

//fade in
		local cfg = { when=Transition.EndNavigation,
		property = "alpha",
		start = 0,
		end = 255,
		time = effect_speed,
		tween = Tween.Cubic
		}

		animation.add( PropertyAnimation( TitleText, cfg ) );
		animation.add( PropertyAnimation( ManufText, cfg ) );
		if (my_config["show_info_icons"] == "on" ) {
			animation.add( PropertyAnimation( playericon, cfg ) );
			animation.add( PropertyAnimation( inputicon, cfg ) );
		}


// Game Info--------------------------------------------------END

// MANAGE SHOW/HIDE artwork when wheel moves etc------------------START

fe.add_transition_callback("manage_show_hide");
function manage_show_hide(ttype, var, ttime) {
    if (ttype == Transition.StartLayout || ttype == Transition.ToNewList || ttype == Transition.EndNavigation) {
        TitleText.visible = true;
        ManufText.visible = true;
        VideoPreviewSurf.visible = true;
        cabpic.visible = true;
        cabpicShadow.visible = true;
        extra_infoText.visible = true;
        if (my_config["show_info_icons"] == "on") {
            playericon.visible = true;
            inputicon.visible = true;
        }
    }

    if (ttype == Transition.ToNewSelection) {
        TitleText.visible = false;
        ManufText.visible = false;
        VideoPreviewSurf.visible = false;
        cabpic.visible = false;
        cabpicShadow.visible = false;
        if (my_config["show_info_icons"] == "on") {
            playericon.visible = false;
            inputicon.visible = false;
        }
        if (my_config["extra_info"] != "display-name") {
            extra_infoText.visible = false;
        }
    }
    return false;
}

// Manage showing/hiding artwork when wheel moves etc------------------END

// WHEEL----------------------------------------START

//local debugTXT = fe.add_text( my_config["wheel_fade_speed"].tofloat()*1000 , 1200, 20, fly*0.48, fly*0.04 );
//debugTXT.zorder=99999

// wheel configuration

local wheel_config = {
    init = function () {
        local archvalue = 60;
        local wheeltype = "vertical";
        if (wheeltype == "arch") archvalue = 60;
        else archvalue = 0;

        // Wheel global parameters
        x <- flw * 0.5;
        y <- fe.layout.height / 2;
        width <- flw;
        height <- flh * my_config["wheel_percent_height"].tointeger() * 0.01;
        slots <- my_config["art_count"].tointeger() + 2;
        speed <- my_config["transition_ms"];
        if (speed == "sync")
            speed = effect_speed * 0.7; //adjusted for wheel decel timing.
        else speed = speed.tointeger();

        artwork_label <- my_config["spinwheel_art"];
        video_flags <- Vid.ImagesOnly;
        preserve_aspect_ratio <- true;
        zorder <- 6950;
        trigger <- Transition.ToNewSelection;
        preset <- "arch-vertical";
        arch <- archvalue;

        // Dynamic table override defines to be updated in update()
        layout.width <- [];
        layout.height <- [];
        layout.alpha <- [];
        layout.origin_y <- [];
        layout.y <- []; //without this, wheel glitches!
    },

    update = function () {
        for (local i = 0; i < slots; i++) {
            layout.width[i] = flh * 0.32 * 0.8;
            layout.height[i] = ((flh * 0.32) / 2.5) * 0.8;
            layout.alpha[i] = my_config["wheel_small_alpha"].tointeger() * 255 * 0.01;
        }

        // current slot
        layout.width[slots / 2] = layout.width[1] * my_config["wheel_selected_size"].tointeger() * 0.01;
        layout.height[slots / 2] = layout.height[1] * my_config["wheel_selected_size"].tointeger() * 0.01;
        layout.alpha[slots / 2] = 255;

        if (my_config["wheel_smooth_resize"] == "yes") {
            // next to current slot
            layout.width[slots / 2 - 1] = layout.width[slots / 2 + 1] = (layout.width[slots / 2] * 2.5) / (2.5 + (my_config["wheel_selected_size"].tointeger() - 100) * 0.01);
            layout.height[slots / 2 - 1] = layout.height[slots / 2 + 1] = (layout.height[slots / 2] * 2.5) / (2.5 + (my_config["wheel_selected_size"].tointeger() - 100) * 0.01);
            layout.origin_y[slots / 2 - 1] = layout.width[slots / 2 - 1] * 0.1;
            layout.origin_y[slots / 2 + 1] = -layout.width[slots / 2 - 1] * 0.1;

            // the 2 neighbors to the above
            layout.width[slots / 2 - 2] = layout.width[slots / 2 + 2] = (layout.width[slots / 2] * 1.5) / (1.5 + (my_config["wheel_selected_size"].tointeger() - 100) * 0.01);
            layout.height[slots / 2 - 2] = layout.height[slots / 2 + 2] = (layout.height[slots / 2] * 1.5) / (1.5 + (my_config["wheel_selected_size"].tointeger() - 100) * 0.01);
            layout.origin_y[slots / 2 - 2] = layout.width[slots / 2 - 2] * 0.05;
            layout.origin_y[slots / 2 + 2] = -layout.width[slots / 2 - 2] * 0.05;
        }
    }
};

// create wheel
local wheel = fe.add_wheel(wheel_config);
wheel = Inertia(wheel, effect_speed, "x", "alpha");

local brightness = my_config["wheel_small_brightness"].tointeger()*255*0.01;

wheel.red = brightness;
wheel.green = brightness;
wheel.blue = brightness;

wheel.sel_slot.red = 255;
wheel.sel_slot.green = 255;
wheel.sel_slot.blue = 255;

// animate wheel

local wheel_x_preset = wheel.x;
wheel.x = flw * 1.2; // out of screen initial position
wheel.to_x = wheel_x_preset;

// don't allow wheel navigation until it enters the screen
allow_navigation <- false;

fe.add_ticks_callback("ticks_wait_for_wheel");
ticks_wait_for_wheel <- function (ttime) {
    if (wheel.x < flw) allow_navigation = true;
};

fe.add_signal_handler("signal_wait_for_wheel");
signal_wait_for_wheel <- function (str) {
    switch (str) {
        case "up":
        case "down":
            if (!allow_navigation) return true;
            break;
    }
    return false;
};

// wheel fading

fade_time <- 0;
fade_delay <- 800;

wheel.time_alpha = my_config["wheel_fade_speed"].tofloat() * 1000;
wheel.tween_alpha = Tween.Linear;

fe.add_transition_callback("transition_wheel_fade");
transition_wheel_fade <- function (ttype, var, ttime) {
    if (ttype == Transition.ToNewSelection || ttype == Transition.ToNewList) {
        wheel.alpha = 255;

        fade_time = fe.layout.time;
    }
    return false;
};

fe.add_ticks_callback("ticks_wheel_alpha");
ticks_wheel_alpha <- function (ttime) {
    if (ttime - fade_time >= fade_delay) {
        wheel.to_alpha = my_config["wheel_fade_alpha"].tointeger() * 255 * 0.01;
    }
};

//add fav star icons
if (my_config["fav_icon"] != "off") {
    //this awesome code by Oomek
    if ((my_config["fav_icon"] == "auto" && fe.list.name != FavoritesDisplayName) || my_config["fav_icon"] == "on") {
        stars <- [];
        stars.push(fe.add_image("assets/general/favs-star.png", 0, 0, 35, 35));
        for (local i = 1; i < wheel.cfg.slots; i++) {
            stars.push(fe.add_clone(stars[0]));
            stars[i].visible = false;
        }
        stars[wheel.selected_slot_idx].width = stars[0].width * my_config["wheel_selected_size"].tointeger() * 0.008;
        stars[wheel.selected_slot_idx].height = stars[0].height * my_config["wheel_selected_size"].tointeger() * 0.008;

        fe.add_ticks_callback("on_tick");
        function on_tick(ttime) {
            foreach (idx, star in stars) {
                star.x = wheel.slots[idx].x;
                star.y = wheel.slots[idx].y + wheel.slots[idx].height / 5;
                star.origin_x = wheel.slots[idx].origin_x;
                star.origin_y = wheel.slots[idx].origin_y;
                star.rotation = wheel.slots[idx].rotation;
                star.alpha = wheel.slots[idx].alpha;
				star.red = star.green = star.blue = wheel.slots[idx].red;   //just match red channel, all 3 are the same anyway
                star.zorder = wheel.slots[idx].zorder + 1;
                local idx_offset = wheel.wheel_idx - wheel.selected_slot_idx + idx;
                idx_offset = wheel.idx2off(idx_offset, ::fe.layout.index);
                if (fe.game_info(Info.Favourite, idx_offset) == "1") star.visible = true;
                else star.visible = false;
            }
        }
    }
}

// Keep selected game entry fully shown, no fading

function tick_update_fullalpha(ttime) {
    wheel.sel_slot.alpha = 255;
    //dont foget star also:
    if (my_config["fav_icon"] != "off")
        if ((my_config["fav_icon"] == "auto" && fe.list.name != FavoritesDisplayName) || my_config["fav_icon"] == "on") {
            stars[wheel.selected_slot_idx].alpha = 255;
        }
}

fe.add_ticks_callback("tick_update_fullalpha");

// play swoosh for wheel in

class StartLayoutAudio {
    active = false;
    time = 0;
    delay = null;
    starttime = 0;
    sound = null;

    constructor(path, sec) {
        delay = sec.tointeger() * 1000;
        sound = fe.add_sound(path);
        sound.playing = false;
        fe.add_transition_callback(this, "Trigger");
        fe.add_ticks_callback(this, "Start");
    }

    function Timer(ttime) {
        time = ttime;
    }

    function Trigger(ttype, var, ttime) {
        switch (ttype) {
            case Transition.StartLayout:
                starttime = time + delay;
                active = true;
                break;
        }
    }

    function Start(ttime) {
        if (active && ttime >= starttime) {
            sound.playing = true;
            active = false;
        }
        Timer(ttime);
    }
}

local start_layout_audio = StartLayoutAudio("assets/sounds/Sound_Wheel_In.mp3", "0"); //change number to any other for a pause i.e. 2 for 2 second pause before playing.

// WHEEL---------------------------------------- END



// RANDOM SPIN WHEEL AT IDLE---------------------------------------- START

if (my_config["idle_time"] != "off") {
    local spinSound = null;
    idle_time <- 0;
    try {
        idle_time = my_config["idle_time"].tointeger();
    }
    catch (e) {
        idle_time = 30;
    }
    if (idle_time <= 0) idle_time = 5;

    idle_time *= 1000 * 60; // multiply by 1000*60 to turn minutes into milliseconds

    switch_time <- 20;
    //try { switch_time = my_config["switch_time"].tointeger() } catch ( e ) { switch_time = 30 }
    //if( switch_time <= 0 )
    //switch_time = 15

    switch_time *= 1000; // multiply by 1000 to turn seconds into milliseconds
    switch_delay <- switch_time;

    spinSound = fe.add_sound("assets/sounds/wheelclick.mp3");

    fe.add_ticks_callback("ticks_timers");
    function ticks_timers(ttime) {
        if (ttime > switch_time) {
			if( !fe.overlay.is_up && !ScreenSaverActive && !IntroActive )   //Decided best if the spin action closes popupinfo altogether to avoid screen burn-in
            {    spinSound.loop = false;
                spinSound.playing = true;
                fe.signal("random_game");
                switch_time = ttime + switch_delay;
            }
        }
    }

    fe.add_transition_callback(this, "transitions_start_idle");
    function transitions_start_idle(ttype, var, ttime) {
        if (ttype == Transition.ToNewList || ttype == Transition.FromGame) switch_time = fe.layout.time + idle_time + switch_delay;

        return false;
    }

    fe.add_signal_handler(this, "signal_restart_idle");
    function signal_restart_idle(str) {
        // reset switch_time in case user makes any input manually
        if (str != "random_game") {
            // except if random spoin triggered by the code
            switch_time = fe.layout.time + idle_time + switch_delay;
        }
        return false;
    }
}

// RANDOM SPIN WHEEL AT IDLE---------------------------------------- END

// SPECIAL ANIMS --------------------------- START

if (my_config["special_anims"] == "on") {
    txt_id <- 2;
    joy_id <- 1;
    new_joy_id <- 1;
    start_anim_delay <- true;
    first_anim <- true;
    anim_counter <- 0;
    txt_c_y <- 0;
    joyx <- flx / 1.47;

    // joystick
    local joy = AnimatedJoystick("red", AnimatedJoystickDirection.Neutral);
    //joy.style = "Cartoonish";
    joy.width = flh / 17.5;
    joy.time = 800;
    joy.x = joyx;
    joy.y = fly * 1.2; //lower (hidden) position

    // center text
    local txt_c = fe.add_image("", joy.x + flh * 0.042, joy.y + baseY - 510, 0.277 * 0.86 * flx, 0.1 * 0.86 * flx);
    txt_c.origin_y = txt_c.height / 2.3;
    txt_c.mipmap = true;
    txt_c.zorder = 6999;

    txt_c = Inertia(txt_c, 1000, "y");
    joy = Inertia(joy, 1000, "y");

    // joystick timers
    pause_bewteen_anims <- 5500;
    anim_delay <- 600 + pause_bewteen_anims;
    delay_time <- anim_delay;
    reload_anim_delay <- 5000 + pause_bewteen_anims;
    reload_anim_play <- reload_anim_delay;

    fe.add_ticks_callback("ticks_hs_anim");
    ticks_hs_anim <- function (tick_time) {
        // reload animations every 'reload_anim_delay' milliseconds
        if (tick_time >= reload_anim_delay) {
            // don't repeat same type of joystick animation
            while (joy_id == new_joy_id) new_joy_id = random(1, 4);

            joy_id = new_joy_id;
            anim_counter++;

            // animate
            joy.to_y = 4000; //lower position
            txt_c.to_y = joy.to_y - 70;

            start_anim_delay = true;
        }

        // delay start of animations when off-screen
        if (start_anim_delay) {
            anim_delay = tick_time + delay_time;
            reload_anim_delay = tick_time + reload_anim_play;
            start_anim_delay = false;
        }

        if (tick_time >= anim_delay) {
            // update joystick animation type only when off-screen
            if (joy.y > flh * 1.2) {
                switch (joy_id.tostring()) {
                    case "1":
                        joy.direction = AnimatedJoystickDirection.Down; // next
                        if (fe.list.display_index < 0) txt_c.file_name = "assets/special/next_genre.png";
                        else txt_c.file_name = "assets/special/next_game.png";
                        joy.x = joyx;
                        joy.to_y = fly * 0.95 + baseY; //upper position
                        txt_c.to_y = joy.to_y - txt_c.height * 0.2;
                        break;
                    case "2":
                        joy.direction = AnimatedJoystickDirection.Up; // previous
                        if (fe.list.display_index < 0) txt_c.file_name = "assets/special/previous_genre.png";
                        else txt_c.file_name = "assets/special/previous_game.png";
                        joy.x = joyx;
                        joy.to_y = fly * 0.95 + baseY; //upper position
                        txt_c.to_y = joy.to_y - txt_c.height * 0.2;
                        break;
                    case "3":
                        joy.direction = AnimatedJoystickDirection.Right; // jump forward
                        txt_c.file_name = "assets/special/jump_forward.png";
                        joy.x = joyx;
                        joy.to_y = fly * 0.95 + baseY; //upper position
                        txt_c.to_y = joy.to_y - txt_c.height * 0.2;
                        break;
                    case "4":
                        joy.direction = AnimatedJoystickDirection.Left; // jump back
                        txt_c.file_name = "assets/special/jump_back.png";
                        joy.x = joyx;
                        joy.to_y = fly * 0.95 + baseY; //upper position
                        txt_c.to_y = joy.to_y - txt_c.height * 0.2;
                        break;
                    default:
                        joy.direction = AnimatedJoystickDirection.Down; // next
                        if (fe.list.display_index < 0) txt_c.file_name = "assets/special/next_genre.png";
                        else txt_c.file_name = "assets/special/next_game.png";
                        joy.x = joyx;
                        joy.to_y = fly * 0.95 + baseY; //upper position
                        txt_c.to_y = joy.to_y - txt_c.height * 0.2;
                        break;
                }
            }
        }
    };

    fe.add_transition_callback("transition_hs_special");
    transition_hs_special <- function (ttype, var, ttime) {
        switch (ttype) {
            case Transition.StartLayout:
                // start layout with next system joystick animation
                joy_id = 1;
                break;
        }
        return false;
    };
}

// SPECIAL ANIMS --------------------------- END

// SEARCH LETTERS popup on screen --------------------------- START

local rtime = 0;
local glob_time = 0;
local glob_delay = 460;
local trigger_letter = false;
local letters = fe.add_image("", wheel_x_preset, fe.layout.height / 2, 200, 200);
letters.mipmap = true;
local letterbackg = fe.add_image("", 0, 0, fe.layout.width, fe.layout.height);
letterbackg.alpha = 200;
letterbackg.zorder = 7499;
letterbackg.visible = false;
letterbackg.preserve_aspect_ratio = false;
letters.preserve_aspect_ratio = true;
letters.origin_x = letters.width / 2;
letters.origin_y = letters.height / 2;
letters.alpha = 255;
letters.zorder = 7500;
letters.visible = false;

fe.add_transition_callback("letter_transition");
function letter_transition(ttype, var, ttime) {
    if (ttype == Transition.ToNewList) rtime = glob_time;
}
fe.add_ticks_callback("letter_tick");
function letter_tick(ttime) {
    glob_time = ttime;
    if (glob_time - rtime > glob_delay) {
        letters.visible = false; // hide letter search if present
        letterbackg.visible = false;
    }
    if (trigger_letter == true) {
        local gameTitle = fe.game_info(Info.Title);
        if (gameTitle.len() > 3 && gameTitle.slice(0, 4).tolower() == "the ") letters.file_name = "assets/letters/" + gameTitle.slice(4, 5).tolower() + ".png";
        else letters.file_name = "assets/letters/" + gameTitle.slice(0, 1).tolower() + ".png";
        letters.visible = true;
        letterbackg.file_name = "assets/general/black.png";
        letterbackg.visible = true;
    }
    trigger_letter = false;
}

fe.add_signal_handler("letter_signal");
function letter_signal(str) {
    switch (str) {
        case "next_letter":
        case "prev_letter":
            rtime = glob_time;
            trigger_letter = true;
            break;
    }
    return false;
}

// Search Letters popup on screen --------------------------- END

// FAVS + EXIT overlay menus -------------------------------------------- START
//***NOTE:  THIS MAY BE OVERRIDEN WITH HIBERNATE PLUGIN.  CHECK IF ENABLED!!!***

// overlay background
local overlay_background = fe.add_image("assets/general/Menu_Background.png", fe.layout.width / 2, fe.layout.height / 2, fe.layout.width, fe.layout.height);
overlay_background.origin_x = overlay_background.width / 2;
overlay_background.origin_y = overlay_background.height / 2;
overlay_background.preserve_aspect_ratio = false;
overlay_background.zorder = 8886;
overlay_background.visible = false;

// overlay menu list box
local overlay_listbox = fe.add_listbox(fe.layout.width * 0.04, fe.layout.height * 0.47, fe.layout.width * 0.92, fe.layout.height * 0.3);
overlay_listbox.rows = 3;
overlay_listbox.set_rgb(255, 255, 255);
overlay_listbox.font = "SF Slapstick Comic Bold Oblique.ttf"; //this free font is for personal use and can be downloaded here: https://www.dafont.com/sf-slapstick-comic.font
overlay_listbox.charsize = fe.layout.width * 0.04;
overlay_listbox.align = Align.MiddleCentre;
overlay_listbox.selbg_alpha = 55;
overlay_listbox.set_selbg_rgb(255, 255, 255);
overlay_listbox.set_sel_rgb(255, 0, 0);
overlay_listbox.zorder = 8887;
overlay_listbox.format_string = "dummy text";
overlay_listbox.visible = false;

// overlay menu title
local overlay_menutitle = fe.add_text("", fe.layout.width * 0.04, fe.layout.height * 0.190, fe.layout.width * 0.92, fe.layout.height * 0.046 * 6);
overlay_menutitle.zorder = overlay_listbox.zorder;
overlay_menutitle.visible = false;
overlay_menutitle.font = "SF Slapstick Comic Bold Oblique.ttf";
//overlay_menutitle.outline = fly*0.00556;
//overlay_menutitle.set_outline_rgb( 0,0,0 );
overlay_menutitle.set_rgb(255, 255, 255);
overlay_menutitle.word_wrap = true;
overlay_menutitle.align = Align.BottomCentre;
overlay_menutitle.charsize = overlay_listbox.charsize * 1.3;

// tell attract-mode we are using a custom overlay menu
fe.overlay.set_custom_controls(overlay_menutitle, overlay_listbox);

// show or hide the overlay menu
fe.add_transition_callback("transition_exit_overlay");
function transition_exit_overlay(ttype, var, ttime) {
    switch (ttype) {
        case Transition.ShowOverlay:
            //start with assumption of a generic dialog:
            overlay_background.file_name = "assets/general/Menu_Background.png";

            if (var == Overlay.Exit || var == Overlay.Custom) {
                //trap exit menu either native or custom exit menu
                //***NOTE:  THIS MAY BE OVERRIDEN WITH HIBERNATE PLUGIN.  CHECK IF ENABLED!!!***
                overlay_menutitle.msg = ""; //remove the exit dialog text since we have an EXIT image for this
                overlay_background.file_name = "assets/general/Menu_Exit_Background1920.png";
            }

            if (var == Overlay.Favourite) {
                //trap fav menu
                overlay_background.file_name = "assets/general/Menu_Background.png"; //use generic black background
                if (fe.game_info(Info.Favourite) == "1") overlay_menutitle.msg = "REMOVE ''[Title]''\nFROM FAVORITES?";
                else overlay_menutitle.msg = "ADD ''[Title]''\nTO FAVORITES?";
            }

			if (var == Overlay.Tags )  {  //trap fav menu
				overlay_listbox.font = "";  // in this case use default lists font so that the tags icon shows.
				overlay_listbox.rows = 6;  // increase rows because there are many tags
				overlay_listbox.height = fe.layout.height*0.52    //change list height to accomodate for increased list rows
			}

            //all other menus will be left as is unless added here.

            overlay_listbox.visible = true;
            overlay_background.visible = true;
            overlay_menutitle.visible = true;
            break;

		case Transition.HideOverlay:
			overlay_listbox.visible = false;
			overlay_background.visible = false;
			overlay_menutitle.visible = false;
			overlay_listbox.font = "SF Slapstick Comic Bold Oblique.ttf";   //default back to preferred font.
			overlay_listbox.rows = 3; //reset to default
			overlay_listbox.height = fe.layout.height*0.3;  //reset to default
			break;
    }
    return false;
}

fe.add_signal_handler("menuControls");
function menuControls(sig) {
    switch (sig) {
        case "back": // Allow exit from any display not only the Genres display.
            // (i.e prevent exit key to go back to genres, and trigger exit menu instead)
            if (fe.list.display_index < 0) {   //this is the displays menu
                //on settings menu we do allow/want 'back' functionality when hitting escape/back etc.
                fe.signal("exit");
                return true;
            }
        case "exit":
            if (fe.list.name != SettingsDisplayName) {
                //on settings menu we do allow/want 'back' functionality when hitting escape/back etc.
                show_dialog(); // Custom dialog for Exit menu with hibernation functionality
                return true;
            }
        default:
            return false;
    }
}

function show_dialog() {
    // Custom dialog for Exit menu with hibernation functionality
    local dialog_title = "";
    local dialog_options = [];
    dialog_options.push("Yes");
    dialog_options.push("No");

    local exitSound = fe.add_sound("assets/sounds/exit.mp3");
    exitSound.loop = false;
    exitSound.playing = true;

    local result = fe.overlay.list_dialog(dialog_options, dialog_title, 1, dialog_options.len() - 1);

    switch (result) {
        case 0:
            if (my_config["exit_action"] == "hibernate") {
                //fe.signal( "exit_to_desktop" );
                fe.plugin_command_bg(@"rundll32.exe", @"powrprof.dll, SetSuspendState 0,1,0"); //hibernate, works on Windows only

                // Manual blocking for 5 seconds using system time
                // local start_time = fe.layout.time;  // Get the current system time in milliseconds
                // local wait_time = 8000;             // milliseconds.  This timing needs to be adjusted to match approx hibernation time so it boots up together with intro

                //while (fe.layout.time - start_time < wait_time)
                //{
                // Looping until xxx seconds have passed
                // This is a busy-wait loop, which blocks the script execution
                //}

                //fe.plugin_command_bg( FeConfigDirectory + "/attractplus.exe", "" )   //launches AM

                //other useful commands:
                //fe.signal( "exit_to_desktop" );
                //fe.plugin_command_bg( FeConfigDirectory + "/attractplus.exe", "" )   //launches AM
                //fe.signal( "intro" )
            }
            else if (my_config["exit_action"] == "shutdown") {
                fe.plugin_command_bg("shutdown", @"/s /t 0"); //shutdown, works on Windows only
            }
            else {
                fe.signal("exit_to_desktop"); //exit normally
            }
            break;

        default:
            break;
    }
}

// FAVS + EXIT overlay menus  -------------------------------------------- END

// FAVORITES KEYPRESS ------------------------------------------------------------------------------- START
// long press of assigned favorites button brings add/remove favorite menu.  Short press goes to favorites.

local hold_timer = 0;
local hold_time = 950;
local hold_button = my_config["fav_key"]; //make sure to assign fav key to custom 2 or whichever in the AM config menus

if (hold_button != "none") {
    fe.add_ticks_callback("hold_button_on_tick");
    function hold_button_on_tick(ttime) {
        local button_held = fe.get_input_state(hold_button);
        if (hold_timer > ttime) hold_timer = ttime; // ttime overflow protection

        if (button_held) {
            if (!hold_timer) {
                // Starting new hold
                hold_timer = ttime;
            }
            else if (ttime - hold_time > hold_timer && hold_timer > 0 && (fe.list.display_index >= 0) && fe.list.name != SettingsDisplayName) {
                // Long press, but ignore long press if in settings or genres menu
                // Long press action
                fe.signal("add_favourite");
                hold_timer = -1; // Mark as long press triggered
            }
        }
        else if (hold_timer > 0) {
            // Button released before long press
            hold_timer = 0;

            // Short press action
            if (fe.list.name != FavoritesDisplayName) {
                //if not already in favorites screen, then switch to favs
                foreach (idx, display in fe.displays) {
                    if (display.name == FavoritesDisplayName) {
                        local mysound = fe.add_sound("assets/sounds/GS35.mp3");
                        mysound.loop = false;
                        mysound.playing = true;
                        while (mysound.playing == true) {
                            //wait till sound finishes playing
                        }
                        fe.set_display(idx);
                        break;
                    }
                }
            } // already in favs screen, do nothing and emit a sound...
            else {
                local errsound = fe.add_sound("assets/sounds/GS25.mp3");
                errsound.loop = false;
                errsound.playing = true;
            }
        }
        else if (hold_timer < 0) {
            // Button released after long press
            hold_timer = 0;
        }
    }
}
// FAVORITES keypress ---------------------------------------------------- END

// SCANLINES --------------------------- START

local scanlinefile = null;

if (my_config["scanline_order"] == "background")
    scanline_zorder <- 4001; //on top of background only
else scanline_zorder <- 8888; //on top of everything

switch (my_config["scanline_type"]) {
    case "loose":
        scanlinefile = "scanlines-loose.png";
        break;
    case "normal":
        scanlinefile = "scanlines-normal.png";
        break;
    case "tight":
        scanlinefile = "scanlines-tight.png";
        break;
    case "CRT":
        scanlinefile = "scanlines-crt.png";
        break;
    case "aperture":
        scanlinefile = "scanlines-aperture.png";
        break;
}

switch (my_config["enable_scanlines"]) {
    case "light":
        local scanlines = fe.add_image("assets/scanlines/" + scanlinefile, 0, 0, fe.layout.width, fe.layout.height);
        scanlines.preserve_aspect_ratio = false;
        scanlines.alpha = 56;
        scanlines.zorder = scanline_zorder;
        break;

    case "medium":
        local scanlines = fe.add_image("assets/scanlines/" + scanlinefile, 0, 0, fe.layout.width, fe.layout.height);
        scanlines.preserve_aspect_ratio = false;
        scanlines.alpha = 80;
        scanlines.zorder = scanline_zorder;
        break;

    case "dark":
        local scanlines = fe.add_image("assets/scanlines/" + scanlinefile, 0, 0, fe.layout.width, fe.layout.height);
        scanlines.preserve_aspect_ratio = false;
        scanlines.alpha = 140;
        scanlines.zorder = scanline_zorder;
        break;
}

// Scanlines --------------------------- END

// TRANSITION TO GAME  ---------------------------------------------------- START

local transitionType = null;
local toGameRunTime = null;
local fromGameRunTime = null;
local shade = null;
local shadeTopmost = null;
local dialog = null;
local startsound = null;
local soundplayed = null;
local transitionOverlay = null;
local topMostFadeDelay = null;
local pauseAfterTransition = null;
local enhancedFadeEffects = "null";

transitionType = my_config["fadeType"];
toGameRunTime = my_config["toGameRunTime"].tointeger();
fromGameRunTime = my_config["fromGameRunTime"].tointeger();
enhancedFadeEffects = my_config["enhancedFadeEffects"];
topMostFadeDelay = 500;
pauseAfterTransition = 750;

dialog = fe.add_image("assets/fade/exitinstructions.png", fe.layout.width / 2, fe.layout.height / 2, 860 / 2, 604 / 2);
dialog.visible = false;
dialog.zorder = scanline_zorder - 1; //use 8887 to keep below bezel
dialog.origin_x = dialog.width / 2;
dialog.origin_y = dialog.height / 2;

shade = fe.add_image("assets/fade/white.png", 0, 0, fe.layout.width, fe.layout.height);
shade.set_rgb(0, 0, 0);
shade.visible = false;
shade.zorder = dialog.zorder - 1;

shadeTopmost = fe.add_image("assets/fade/white.png", 0, 0, fe.layout.width, fe.layout.height);
shadeTopmost.set_rgb(0, 0, 0);
shadeTopmost.visible = false;
shadeTopmost.zorder = 99999; //place above everything

startsound = fe.add_sound("assets/sounds/startgame.wav");
startsound.loop = false;
soundplayed = false;

transitionOverlay = fe.add_image("", fe.layout.width / 2, fe.layout.height / 2, 2, 2);
transitionOverlay.origin_x = transitionOverlay.width / 2;
transitionOverlay.origin_y = transitionOverlay.height / 2;
transitionOverlay.alpha = 255;
transitionOverlay.visible = false;
transitionOverlay.preserve_aspect_ratio = false;
transitionOverlay.zorder = dialog.zorder - 1;

fe.add_transition_callback("transitions");

function transitions(ttype, var, ttime) {
    if (transitionType != "off") {
        switch (ttype) {
            case Transition.ToGame:
                if (startsound.playing != true && soundplayed == false) {
                    startsound.playing = true;
                }

                soundplayed = true;

                dialog.visible = true;

                if (transitionType == "square-iris") {
                    transitionOverlay.visible = true;
                    if (ttime <= toGameRunTime) {
                        // Transition Out
                        transitionOverlay.file_name = "assets/fade/black.png";
                        transitionOverlay.height = fe.layout.height - (fe.layout.height * (toGameRunTime - ttime)) / toGameRunTime;
                        transitionOverlay.width = fe.layout.width - (fe.layout.width * (toGameRunTime - ttime)) / toGameRunTime;
                        transitionOverlay.origin_x = transitionOverlay.width / 2;
                        transitionOverlay.origin_y = transitionOverlay.height / 2;

                        // No topmost fade effect yet
                        shadeTopmost.visible = false;

                        return true;
                    }

                    //pause after the transition finishes
                    else if (ttime > toGameRunTime && ttime <= toGameRunTime + pauseAfterTransition && (enhancedFadeEffects == "medium" || enhancedFadeEffects == "high")) {
                        // Pause in the transition (do nothing)
                        return true;
                    }

                    // Start fade to black effect after the pause and transition is complete
                    else if (ttime > toGameRunTime + pauseAfterTransition && ttime <= toGameRunTime + pauseAfterTransition + topMostFadeDelay && (enhancedFadeEffects == "medium" || enhancedFadeEffects == "high")) {
                        shadeTopmost.visible = true;
                        shadeTopmost.alpha = (255 * (ttime - (toGameRunTime + pauseAfterTransition))) / topMostFadeDelay; // Fade to black over 'topMostFadeDelay' ms

                        if (enhancedFadeEffects == "high") {
                            dialog.width = dialog.width * 1.02;
                            dialog.height = dialog.height * 1.02;
                            dialog.origin_x = dialog.width / 2;
                            dialog.origin_y = dialog.height / 2;
                        }

                        return true;
                    }
                }
                else if (transitionType == "round-iris") {
                    transitionOverlay.visible = true;

                    // Round Iris Effect: Shrinks the circle during the initial phase
                    if (ttime <= toGameRunTime) {
                        transitionOverlay.file_name = "assets/fade/circle.png";
                        transitionOverlay.height = 1.5 * fe.layout.width - (1.5 * fe.layout.width * (toGameRunTime - ttime)) / toGameRunTime; //width here too so it scales uniformly
                        transitionOverlay.width = 1.5 * fe.layout.width - (1.5 * fe.layout.width * (toGameRunTime - ttime)) / toGameRunTime;
                        transitionOverlay.origin_x = transitionOverlay.width / 2;
                        transitionOverlay.origin_y = transitionOverlay.height / 2;

                        // No topmost fade effect yet
                        shadeTopmost.visible = false;
                        return true;
                    }

                    //pause after the transition finishes
                    else if (ttime > toGameRunTime && ttime <= toGameRunTime + pauseAfterTransition && (enhancedFadeEffects == "medium" || enhancedFadeEffects == "high")) {
                        // Pause in the transition (do nothing)
                        return true;
                    }

                    // Start fade to black effect after the pause and transition is complete
                    else if (ttime > toGameRunTime + pauseAfterTransition && ttime <= toGameRunTime + pauseAfterTransition + topMostFadeDelay && (enhancedFadeEffects == "medium" || enhancedFadeEffects == "high")) {
                        shadeTopmost.visible = true;
                        shadeTopmost.alpha = (255 * (ttime - (toGameRunTime + pauseAfterTransition))) / topMostFadeDelay; // Fade to black over 'topMostFadeDelay' ms

                        if (enhancedFadeEffects == "high") {
                            dialog.width = dialog.width * 1.02;
                            dialog.height = dialog.height * 1.02;
                            dialog.origin_x = dialog.width / 2;
                            dialog.origin_y = dialog.height / 2;
                        }

                        return true;
                    }
                }
                else {
                    //regular pure fade effect
                    shade.visible = true;
                    if (ttime < toGameRunTime) {
                        // Transition Out
                        shade.alpha = (255 * (ttime - toGameRunTime)) / toGameRunTime;

                        // No topmost fade effect yet
                        shadeTopmost.visible = false;
                        return true;
                    }

                    //pause after the transition finishes
                    else if (ttime >= toGameRunTime && ttime <= toGameRunTime + pauseAfterTransition && (enhancedFadeEffects == "medium" || enhancedFadeEffects == "high")) {
                        // Pause in the transition (do nothing)
                        return true;
                    }

                    // Start fade to black effect after the pause and transition is complete
                    else if (ttime > toGameRunTime + pauseAfterTransition && ttime <= toGameRunTime + pauseAfterTransition + topMostFadeDelay && (enhancedFadeEffects == "medium" || enhancedFadeEffects == "high")) {
                        shadeTopmost.visible = true;
                        shadeTopmost.alpha = (255 * (ttime - (toGameRunTime + pauseAfterTransition))) / topMostFadeDelay; // Fade to black over 'topMostFadeDelay' ms

                        if (enhancedFadeEffects == "high") {
                            dialog.width = dialog.width * 1.02;
                            dialog.height = dialog.height * 1.02;
                            dialog.origin_x = dialog.width / 2;
                            dialog.origin_y = dialog.height / 2;
                        }

                        return true;
                    }
                }

                if (ttime < 2000)
                    //always run for at least 2.0 seconds to make sure dialog is read...
                    return true;

                break;

            case Transition.FromGame:
                dialog.visible = false;
                soundplayed = false;
                dialog.width = 860 / 2;
                dialog.height = 604 / 2;
                dialog.origin_x = dialog.width / 2;
                dialog.origin_y = dialog.height / 2;
                transitionOverlay.visible = false;
                shade.visible = false;
                shadeTopmost.visible = false;

                if (transitionType == "square-iris") {
                    transitionOverlay.visible = true;
                    if (ttime < fromGameRunTime) {
                        // Transition In
                        transitionOverlay.file_name = "assets/fade/black.png";
                        transitionOverlay.height = (fe.layout.height * (fromGameRunTime - ttime)) / fromGameRunTime;
                        transitionOverlay.width = (fe.layout.width * (fromGameRunTime - ttime)) / fromGameRunTime;
                        transitionOverlay.origin_x = transitionOverlay.width / 2;
                        transitionOverlay.origin_y = transitionOverlay.height / 2;
                        return true;
                    }
                }
                else if (transitionType == "round-iris") {
                    transitionOverlay.visible = true;
                    if (ttime < fromGameRunTime) {
                        // Transition In
                        transitionOverlay.file_name = "assets/fade/circle.png";
                        transitionOverlay.height = (1.5 * fe.layout.width * (fromGameRunTime - ttime)) / fromGameRunTime; //width here too so it scales uniformly
                        transitionOverlay.width = (1.5 * fe.layout.width * (fromGameRunTime - ttime)) / fromGameRunTime;
                        transitionOverlay.origin_x = transitionOverlay.width / 2;
                        transitionOverlay.origin_y = transitionOverlay.height / 2;
                        return true;
                    }
                }
                else {
                    shade.visible = true;
                    if (ttime < fromGameRunTime) {
                        // Transition In
                        shade.alpha = (255 * (fromGameRunTime - ttime)) / fromGameRunTime;
                        return true;
                    }
                }

                break;
        }

        shade.visible = false;
        shadeTopmost.visible = false;
        transitionOverlay.visible = false;
        soundplayed = false;
        dialog.visible = false;
        dialog.width = 860 / 2;
        dialog.height = 604 / 2;
        dialog.origin_x = dialog.width / 2;
        dialog.origin_y = dialog.height / 2;

        return false;
    }
}

// TRANSITION TO GAME  ---------------------------------------------------- END
